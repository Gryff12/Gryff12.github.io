#ifndef MECHANIC_PULSATION_SHAPE_H
#define MECHANIC_PULSATION_SHAPE_H

void draw_triangle(float points[], unsigned int indexes[], unsigned int buffer_size, unsigned int index_buffer_size);

#endif // MECHANIC_PULSATION_SHAPE_H
